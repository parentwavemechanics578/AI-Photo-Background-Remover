start binl.exe util.txt
